package paquetepolimorfismo;

public class Uso_Empleado {

	public static void main(String[] args) {

		Empleado[] misEmpleados = new Empleado[4];
		
		misEmpleados[0] = new Empleado ("Ana",30000,2000,07,07);
		misEmpleados[1] = new Empleado ("Carlos",30300,2002,07,02);
		misEmpleados[2] = new Empleado ("Paco",35000,2003,07,03);
		misEmpleados[3] = new Empleado ("Antonio",39000,2008,8,07);
		
		for(Empleado e:misEmpleados) {
			
			e.subeSueldo(5);
		}
		
		for(Empleado e : misEmpleados) {
			
			System.out.println("nombre: " + e.dameNombre()+" Sueldo: "+e.dameSueldo()+ " Fecha de Alta: "+e.dameFechaContrato());
			
		}

	}

}
